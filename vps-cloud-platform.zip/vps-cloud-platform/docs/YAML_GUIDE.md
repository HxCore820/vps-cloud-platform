# 📝 HƯỚNG DẪN CHỈNH SỬA VPS-CONFIG.YAML

## 🎯 TỔNG QUAN

File `vps-config.yml` là **SINGLE SOURCE OF TRUTH** của toàn bộ hệ thống VPS Cloud Platform.

**Mọi thay đổi trong file này sẽ tự động ảnh hưởng đến:**
- ✅ Frontend UI (gói VPS, điểm, giới hạn)
- ✅ Backend API (logic tính điểm, validation)
- ✅ GitHub Actions (cấu hình VPS, giới hạn)

---

## 📚 CẤU TRÚC FILE YAML

### 1. THÔNG TIN HỆ THỐNG (`system`)

```yaml
system:
  name: "VPS Cloud Vietnam"           # Tên hệ thống
  version: "1.0.0"                     # Version
  currency: "điểm"                     # Đơn vị điểm
  default_vps_duration_hours: 6        # Thời gian VPS mặc định
  max_vps_per_user: 3                  # Tối đa VPS/người
```

**Khi nào chỉnh sửa:**
- Đổi tên hệ thống
- Thay đổi thời gian VPS miễn phí (6 giờ → 12 giờ)
- Tăng/giảm số VPS tối đa mỗi user

**Ví dụ:**
```yaml
system:
  default_vps_duration_hours: 12  # Thay từ 6 → 12 giờ miễn phí
  max_vps_per_user: 5              # Tăng từ 3 → 5 VPS
```

---

### 2. CÁC GÓI VPS (`vps_plans`)

```yaml
vps_plans:
  basic:                              # ID gói (dùng trong code)
    name: "Gói Cơ Bản"                # Tên hiển thị
    cpu_cores: 1                      # Số CPU
    ram_gb: 1                         # RAM (GB)
    disk_gb: 20                       # Ổ cứng (GB)
    bandwidth_mbps: 100               # Băng thông (Mbps)
    points_per_hour: 10               # Điểm/giờ
    points_per_6_hours: 60            # Điểm cho 6 giờ
    description: "Mô tả gói"          # Mô tả
    icon: "🌱"                        # Icon emoji
```

#### 2.1. THÊM GÓI MỚI

**Ví dụ: Thêm gói "Enterprise"**

```yaml
vps_plans:
  # ... các gói cũ ...
  
  enterprise:                         # ID mới
    name: "Gói Doanh Nghiệp"
    cpu_cores: 8
    ram_gb: 16
    disk_gb: 250
    bandwidth_mbps: 2000
    points_per_hour: 200
    points_per_6_hours: 1200
    description: "Cho ứng dụng doanh nghiệp quy mô lớn"
    icon: "🏢"
```

#### 2.2. CHỈNH SỬA ĐIỂM CỦA GÓI

**Ví dụ: Giảm giá gói Basic**

```yaml
vps_plans:
  basic:
    points_per_hour: 8               # Giảm từ 10 → 8
    points_per_6_hours: 48           # Giảm từ 60 → 48
```

**Công thức:**
```
points_per_6_hours = points_per_hour × 6
```

#### 2.3. XÓA GÓI

Chỉ cần xóa toàn bộ block của gói đó:

```yaml
vps_plans:
  # basic: ...              # ← Comment hoặc xóa hẳn
  standard: ...
  # ...
```

⚠️ **Lưu ý**: Nếu có user đang dùng gói này, hệ thống sẽ lỗi!

---

### 3. CẤU HÌNH TÙY CHỈNH (`custom_config`)

```yaml
custom_config:
  cpu_options:                        # Các option CPU
    - cores: 1
      multiplier: 1.0                 # Hệ số nhân
    - cores: 2
      multiplier: 2.0
    - cores: 4
      multiplier: 4.0
      
  ram_options:                        # Các option RAM
    - size_gb: 1
      multiplier: 1.0
    - size_gb: 2
      multiplier: 1.8
    - size_gb: 4
      multiplier: 3.5
    - size_gb: 8
      multiplier: 7.0
      
  base_points_per_hour: 10            # Điểm cơ bản/giờ
```

#### 3.1. CÔNG THỨC TÍNH ĐIỂM

```
điểm/giờ = base_points_per_hour × cpu_multiplier × ram_multiplier
```

**Ví dụ: VPS 2 CPU + 4GB RAM**
```
= 10 × 2.0 × 3.5
= 70 điểm/giờ
```

#### 3.2. THÊM OPTION CPU MỚI

```yaml
cpu_options:
  # ... các option cũ ...
  - cores: 8                          # Thêm 8 cores
    multiplier: 8.0
  - cores: 16                         # Thêm 16 cores
    multiplier: 16.0
```

#### 3.3. THAY ĐỔI HỆ SỐ

**Ví dụ: Giảm giá RAM**

```yaml
ram_options:
  - size_gb: 8
    multiplier: 6.0                   # Giảm từ 7.0 → 6.0
```

→ VPS 4 CPU + 8GB RAM giờ chỉ còn: `10 × 4.0 × 6.0 = 240 điểm/giờ` (thay vì 280)

#### 3.4. THAY ĐỔI GIÁ CƠ BẢN

```yaml
custom_config:
  base_points_per_hour: 15            # Tăng từ 10 → 15
```

→ **Tất cả gói VPS sẽ tăng giá 50%**

---

### 4. HỆ THỐNG ĐIỂM (`points_system`)

```yaml
points_system:
  initial_points: 100                 # Điểm khởi đầu
  
  watch_ad:                           # Xem quảng cáo
    points_reward: 5                  # Điểm nhận
    cooldown_minutes: 5               # Thời gian chờ
    max_per_day: 50                   # Tối đa/ngày
    
  shortlink:                          # Vượt link rút gọn
    points_reward: 10
    cooldown_minutes: 10
    max_per_day: 30
    
  daily_missions:                     # Nhiệm vụ hằng ngày
    login_daily:
      points: 20
      description: "Đăng nhập hàng ngày"
```

#### 4.1. TĂNG ĐIỂM KHỞI ĐẦU

```yaml
points_system:
  initial_points: 200                 # Tăng từ 100 → 200
```

#### 4.2. THAY ĐỔI PHẦN THƯỞNG QUẢNG CÁO

```yaml
watch_ad:
  points_reward: 10                   # Tăng từ 5 → 10
  cooldown_minutes: 3                 # Giảm từ 5 → 3 phút
  max_per_day: 100                    # Tăng từ 50 → 100
```

#### 4.3. THÊM NHIỆM VỤ MỚI

```yaml
daily_missions:
  # ... nhiệm vụ cũ ...
  
  share_social:                       # Nhiệm vụ mới
    points: 50
    description: "Chia sẻ lên mạng xã hội"
    
  rate_app:
    points: 100
    description: "Đánh giá ứng dụng 5 sao"
```

---

### 5. HỆ ĐIỀU HÀNH (`operating_systems`)

```yaml
operating_systems:
  ubuntu_22:
    name: "Ubuntu 22.04 LTS"
    type: "linux"
    icon: "🐧"
    docker_image: "ubuntu:22.04"
```

#### 5.1. THÊM HỆ ĐIỀU HÀNH MỚI

```yaml
operating_systems:
  # ... các OS cũ ...
  
  rocky_linux_9:                      # OS mới
    name: "Rocky Linux 9"
    type: "linux"
    icon: "🪨"
    docker_image: "rockylinux:9"
```

#### 5.2. TĂNG GIÁ CHO WINDOWS

```yaml
windows_server_2022:
  extra_points_multiplier: 2.0        # Tăng từ 1.5 → 2.0
```

→ Windows sẽ tốn gấp đôi điểm so với Linux

---

### 6. GIA HẠN VPS (`extension`)

```yaml
extension:
  per_hour: 10                        # Điểm/giờ gia hạn
  max_extension_hours: 12             # Tối đa gia hạn
  discount_bulk:                      # Giảm giá khi mua nhiều
    6_hours: 0.9                      # Giảm 10%
    12_hours: 0.8                     # Giảm 20%
```

#### 6.1. THAY ĐỔI GIÁ GIA HẠN

```yaml
extension:
  per_hour: 8                         # Giảm từ 10 → 8
```

#### 6.2. THÊM DISCOUNT MỚI

```yaml
discount_bulk:
  6_hours: 0.9
  12_hours: 0.8
  24_hours: 0.7                       # Giảm 30% cho 24h
```

---

### 7. GIỚI HẠN HỆ THỐNG (`limits`)

```yaml
limits:
  cpu:
    min: 1
    max: 4                            # Tối đa 4 cores
  ram:
    min: 1
    max: 8                            # Tối đa 8GB
  disk:
    min: 20
    max: 120
  max_active_vps: 3                   # Tối đa 3 VPS cùng lúc
  max_total_cpu: 8                    # Tổng CPU tối đa
  max_total_ram: 16                   # Tổng RAM tối đa
```

#### 7.1. TĂNG GIỚI HẠN

```yaml
limits:
  cpu:
    max: 8                            # Tăng từ 4 → 8
  ram:
    max: 16                           # Tăng từ 8 → 16
  max_active_vps: 5                   # Tăng từ 3 → 5
```

#### 7.2. GIỚI HẠN TỔNG TÀI NGUYÊN

```yaml
limits:
  max_total_cpu: 16                   # User có thể tạo nhiều VPS
  max_total_ram: 32                   # nhưng tổng không quá giới hạn
```

**Ví dụ:**
- User tạo VPS1: 4 CPU + 8GB RAM
- User tạo VPS2: 4 CPU + 8GB RAM
- User tạo VPS3: ❌ Không thể (vượt max_total_cpu)

---

## 🔄 QUY TRÌNH UPDATE YAML

### Bước 1: Chỉnh Sửa File

```bash
nano vps-config.yml
```

### Bước 2: Validate YAML

Kiểm tra syntax tại: https://www.yamllint.com/

Hoặc dùng command:
```bash
python -c 'import yaml; yaml.safe_load(open("vps-config.yml"))'
```

### Bước 3: Commit & Push

```bash
git add vps-config.yml
git commit -m "Update VPS config: [mô tả thay đổi]"
git push
```

### Bước 4: Kiểm Tra

1. **Frontend**: Reload trang, check gói VPS mới
2. **Backend**: API `/api/config` trả về đúng
3. **GitHub Actions**: Chạy workflow test

---

## ⚠️ LƯU Ý QUAN TRỌNG

### 1. Syntax YAML

- ✅ Dùng **spaces** để indent (không dùng tabs)
- ✅ Mỗi level indent = 2 spaces
- ✅ Key và value cách nhau bằng `: ` (có space)
- ✅ String có ký tự đặc biệt → đặt trong quotes

**Đúng:**
```yaml
name: "Gói Cơ Bản"
points: 100
```

**Sai:**
```yaml
name:"Gói Cơ Bản"    # Thiếu space
    points: 100       # Tab thay vì space
```

### 2. Consistency

Khi thay đổi điểm, đảm bảo:
```yaml
points_per_6_hours = points_per_hour × 6
```

### 3. Backwards Compatibility

- Không xóa field đang được dùng
- Thêm field mới → thêm giá trị mặc định trong code

### 4. Testing

Sau mỗi update:
- ✅ Test tạo VPS mới
- ✅ Test tính điểm
- ✅ Test giới hạn
- ✅ Check logs

---

## 📊 EXAMPLES

### Example 1: Tạo Chương Trình Khuyến Mãi

**Giảm 50% tất cả gói trong tuần**

```yaml
vps_plans:
  basic:
    points_per_6_hours: 30            # Từ 60 → 30
  standard:
    points_per_6_hours: 60            # Từ 120 → 60
  premium:
    points_per_6_hours: 240           # Từ 480 → 240
```

### Example 2: Free Tier Hào Phóng Hơn

```yaml
points_system:
  initial_points: 500                 # Tăng 5x
  
  watch_ad:
    points_reward: 20                 # Tăng 4x
    max_per_day: 200                  # Tăng 4x
```

### Example 3: VIP Plan

```yaml
vps_plans:
  vip:
    name: "Gói VIP"
    cpu_cores: 16
    ram_gb: 32
    disk_gb: 500
    bandwidth_mbps: 10000
    points_per_hour: 500
    points_per_6_hours: 3000
    description: "Cho doanh nghiệp lớn và startup unicorn"
    icon: "💎"
```

---

## 🆘 TROUBLESHOOTING

### Lỗi: "Invalid YAML syntax"

**Nguyên nhân**: Syntax sai

**Giải pháp**:
1. Check tại yamllint.com
2. Đảm bảo indent đúng
3. Check quotes và colons

### Lỗi: "Config not loading"

**Nguyên nhân**: Backend chưa restart

**Giải pháp**:
```bash
pm2 restart vps-cloud-backend
```

### Lỗi: "Points calculation wrong"

**Nguyên nhân**: Công thức không đồng bộ

**Giải pháp**:
1. Check `custom_config.base_points_per_hour`
2. Check CPU/RAM multipliers
3. Verify: `points_per_6_hours = points_per_hour × 6`

---

## ✅ CHECKLIST

Trước khi push YAML mới:

- [ ] Syntax đã validate
- [ ] Công thức điểm đã kiểm tra
- [ ] Giới hạn hợp lý
- [ ] Không xóa field đang dùng
- [ ] Đã commit với message rõ ràng
- [ ] Đã test local
- [ ] Đã backup file cũ

---

**🎉 Chúc bạn thành công với việc tùy chỉnh hệ thống!**
