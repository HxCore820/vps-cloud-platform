# 🚀 HƯỚNG DẪN TRIỂN KHAI HỆ THỐNG VPS CLOUD PLATFORM

## 📋 MỤC LỤC
1. [Yêu Cầu Hệ Thống](#yêu-cầu-hệ-thống)
2. [Cấu Hình Firebase](#cấu-hình-firebase)
3. [Cấu Hình GitHub Actions](#cấu-hình-github-actions)
4. [Cài Đặt Backend](#cài-đặt-backend)
5. [Deploy Frontend](#deploy-frontend)
6. [Chỉnh Sửa Cấu Hình YAML](#chỉnh-sửa-yaml)
7. [Vận Hành & Bảo Trì](#vận-hành)

---

## 1️⃣ YÊU CẦU HỆ THỐNG

### Phần Mềm Cần Thiết
- **Node.js** >= 18.0.0
- **npm** hoặc **yarn**
- **Git**
- **GitHub Account** (với Actions enabled)
- **Firebase Account** (plan Blaze để dùng Firebase Functions)

### Kiến Thức Cần Có
- Cơ bản về Git/GitHub
- Hiểu biết về Node.js
- Cơ bản về Firebase/Firestore
- Hiểu về YAML syntax

---

## 2️⃣ CẤU HÌNH FIREBASE

### Bước 1: Tạo Firebase Project

1. Truy cập: https://console.firebase.google.com
2. Click **"Add project"**
3. Nhập tên project: `vps-cloud-vietnam`
4. Bật Google Analytics (tùy chọn)
5. Click **"Create project"**

### Bước 2: Enable Firestore Database

1. Trong Firebase Console, chọn **"Firestore Database"**
2. Click **"Create database"**
3. Chọn location: **asia-southeast1** (Singapore)
4. Start in **Production mode**

### Bước 3: Tạo Collections

Firestore sẽ tự động tạo collections khi có data, nhưng bạn có thể tạo trước:

```
users/
  └── {userId}
      ├── email: string
      ├── name: string
      ├── points: number
      ├── created_at: timestamp
      └── last_login: timestamp

vps_instances/
  └── {vpsId}
      ├── user_id: string
      ├── cpu_cores: number
      ├── ram_gb: number
      ├── os_type: string
      ├── status: string ('running', 'stopped')
      ├── created_at: timestamp
      └── expires_at: timestamp

points_history/
  └── {transactionId}
      ├── user_id: string
      ├── amount: number
      ├── type: string ('earn', 'spend')
      ├── description: string
      └── timestamp: timestamp

transactions/
  └── {transactionId}
      ├── user_id: string
      ├── vps_id: string
      ├── points_spent: number
      └── timestamp: timestamp
```

### Bước 4: Tạo Service Account

1. Trong Firebase Console, click vào **⚙️ Settings** > **Project settings**
2. Tab **"Service accounts"**
3. Click **"Generate new private key"**
4. Download file JSON
5. Đổi tên file thành: `serviceAccountKey.json`
6. Copy vào thư mục: `/firebase/serviceAccountKey.json`

⚠️ **LƯU Ý**: File này KHÔNG được commit lên Git (đã có trong .gitignore)

### Bước 5: Cấu Hình Firebase Rules

Trong Firestore, tab **"Rules"**, paste code sau:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users collection
    match /users/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // VPS instances
    match /vps_instances/{vpsId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    
    // Points history
    match /points_history/{transactionId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
    }
    
    // Transactions
    match /transactions/{transactionId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
    }
  }
}
```

---

## 3️⃣ CẤU HÌNH GITHUB ACTIONS

### Bước 1: Fork/Upload Repository

1. Tạo repository mới trên GitHub: `vps-cloud-platform`
2. Upload toàn bộ code lên repository

```bash
cd vps-cloud-platform
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vps-cloud-platform.git
git push -u origin main
```

### Bước 2: Enable GitHub Actions

1. Vào repository trên GitHub
2. Tab **"Actions"**
3. Click **"I understand my workflows, go ahead and enable them"**

### Bước 3: Thêm Secrets

1. Vào **Settings** > **Secrets and variables** > **Actions**
2. Click **"New repository secret"**

Thêm các secrets sau:

**FIREBASE_SERVICE_ACCOUNT**
```json
{
  "type": "service_account",
  "project_id": "vps-cloud-vietnam",
  "private_key_id": "...",
  "private_key": "...",
  ...
}
```
(Copy toàn bộ nội dung file serviceAccountKey.json)

**FIREBASE_DATABASE_URL** (tùy chọn)
```
https://vps-cloud-vietnam.firebaseio.com
```

---

## 4️⃣ CÀI ĐẶT BACKEND

### Bước 1: Cài Đặt Dependencies

```bash
cd backend
npm install
```

### Bước 2: Tạo File .env

Tạo file `.env` trong thư mục `/backend`:

```env
NODE_ENV=development
PORT=3000
FIREBASE_DATABASE_URL=https://vps-cloud-vietnam.firebaseio.com
JWT_SECRET=your-super-secret-key-change-this
```

### Bước 3: Chạy Backend Locally

```bash
# Development mode (với nodemon)
npm run dev

# Production mode
npm start
```

Server sẽ chạy tại: http://localhost:3000

### Bước 4: Test API

```bash
# Health check
curl http://localhost:3000/api/health

# Load config
curl http://localhost:3000/api/config
```

---

## 5️⃣ DEPLOY FRONTEND

### Option 1: GitHub Pages

1. Vào **Settings** > **Pages**
2. Source: Deploy from a branch
3. Branch: `main`, folder: `/frontend`
4. Click **"Save"**

Website sẽ có tại: `https://YOUR_USERNAME.github.io/vps-cloud-platform/`

### Option 2: Netlify

1. Truy cập: https://netlify.com
2. Click **"Add new site"** > **"Import an existing project"**
3. Chọn GitHub repository
4. Build settings:
   - Base directory: `frontend`
   - Build command: (để trống)
   - Publish directory: `/`
5. Click **"Deploy"**

### Option 3: Vercel

```bash
npm install -g vercel
cd frontend
vercel
```

---

## 6️⃣ CHỈNH SỬA CẤU HÌNH YAML

### File: `vps-config.yml`

Đây là **SINGLE SOURCE OF TRUTH** của toàn bộ hệ thống.

### Thay Đổi Điểm Của Gói VPS

```yaml
vps_plans:
  basic:
    points_per_6_hours: 60  # Thay đổi từ 60 → 50
```

### Thêm Gói VPS Mới

```yaml
vps_plans:
  enterprise:  # Gói mới
    name: "Gói Doanh Nghiệp"
    cpu_cores: 8
    ram_gb: 16
    disk_gb: 200
    bandwidth_mbps: 2000
    points_per_hour: 150
    points_per_6_hours: 900
    description: "Cho ứng dụng doanh nghiệp lớn"
    icon: "🏢"
```

### Thay Đổi Công Thức Tính Điểm

```yaml
custom_config:
  base_points_per_hour: 15  # Tăng từ 10 → 15
  
  cpu_options:
    - cores: 8              # Thêm option 8 cores
      multiplier: 8.0
```

### Thay Đổi Giới Hạn Hệ Thống

```yaml
limits:
  cpu:
    max: 8                  # Tăng từ 4 → 8
  ram:
    max: 16                 # Tăng từ 8 → 16
  max_active_vps: 5         # Tăng từ 3 → 5
```

### Sau Khi Chỉnh YAML

1. **Commit & Push**
```bash
git add vps-config.yml
git commit -m "Update VPS configuration"
git push
```

2. **Hệ thống tự động cập nhật**:
   - Frontend đọc config mới từ API
   - Backend reload config
   - GitHub Actions sử dụng config mới

---

## 7️⃣ VẬN HÀNH & BẢO TRÌ

### Monitor Backend

```bash
# Xem logs
pm2 logs

# Restart
pm2 restart vps-cloud-backend

# Status
pm2 status
```

### Monitor GitHub Actions

1. Vào repository > **Actions**
2. Xem các workflow runs
3. Check logs nếu có lỗi

### Backup Database

```bash
# Export Firestore
gcloud firestore export gs://YOUR_BUCKET/backup-$(date +%Y%m%d)
```

### Update Dependencies

```bash
cd backend
npm update
npm audit fix
```

---

## 🆘 TROUBLESHOOTING

### Lỗi: "Cannot read vps-config.yml"

**Nguyên nhân**: File YAML không đúng cấu trúc

**Giải pháp**:
1. Kiểm tra syntax YAML tại: https://www.yamllint.com/
2. Đảm bảo indentation đúng (dùng spaces, không dùng tabs)

### Lỗi: "Firebase permission denied"

**Nguyên nhân**: Firestore Rules chưa đúng

**Giải pháp**:
1. Kiểm tra Firestore Rules
2. Đảm bảo user đã authenticated

### Lỗi: "GitHub Actions timeout"

**Nguyên nhân**: VPS chạy quá 6 giờ (360 phút)

**Giải pháp**:
1. Giảm `default_vps_duration_hours` trong YAML
2. Hoặc tăng `timeout-minutes` trong workflow

---

## 📞 HỖ TRỢ

- **Documentation**: https://docs.vpscloud.vn
- **GitHub Issues**: https://github.com/YOUR_USERNAME/vps-cloud-platform/issues
- **Discord**: https://discord.gg/vpscloud

---

## ✅ CHECKLIST DEPLOY

- [ ] Firebase project đã tạo
- [ ] Firestore database đã enable
- [ ] Service Account Key đã tạo
- [ ] GitHub repository đã tạo
- [ ] GitHub Actions đã enable
- [ ] Secrets đã thêm vào GitHub
- [ ] Backend dependencies đã cài
- [ ] Backend đang chạy
- [ ] Frontend đã deploy
- [ ] Test tạo VPS thành công
- [ ] Hệ thống điểm hoạt động
- [ ] YAML config đã kiểm tra

**Chúc mừng! Hệ thống của bạn đã sẵn sàng! 🎉**
