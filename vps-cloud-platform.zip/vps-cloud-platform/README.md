# 🌐 VPS CLOUD VIETNAM - HỆ THỐNG VPS MIỄN PHÍ CHUYÊN NGHIỆP

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)
![Platform](https://img.shields.io/badge/platform-GitHub%20Actions-orange.svg)

## 📋 TỔNG QUAN

**VPS Cloud Vietnam** là nền tảng cung cấp máy chủ ảo (VPS) miễn phí với cấu hình linh hoạt, được triển khai hoàn toàn qua GitHub Actions.

### ✨ Tính Năng Nổi Bật

- 🖥️ **VPS Miễn Phí 6 Giờ** - Mỗi VPS được sử dụng miễn phí trong 6 giờ
- ⚙️ **Cấu Hình Linh Hoạt** - Chọn CPU (1-4 cores) và RAM (1-8GB) tùy ý
- 🎯 **Hệ Thống Điểm** - Kiếm điểm qua quảng cáo, link rút gọn, nhiệm vụ
- 🐧 **Nhiều Hệ Điều Hành** - Ubuntu, Debian, CentOS, Windows Server
- 🔄 **Tự Động Hóa Hoàn Toàn** - Deploy qua GitHub Actions
- 📝 **YAML Configuration** - Single source of truth

### 🏗️ Kiến Trúc

```
┌─────────────┐      ┌──────────────┐      ┌─────────────────┐
│   Frontend  │─────▶│   Backend    │─────▶│ GitHub Actions  │
│ (HTML/CSS)  │      │  (Node.js)   │      │   (VPS Runner)  │
└─────────────┘      └──────────────┘      └─────────────────┘
       │                     │                       │
       └─────────────────────┼───────────────────────┘
                             ▼
                      ┌─────────────┐
                      │   Firebase  │
                      │  (Database) │
                      └─────────────┘
```

## 🚀 QUICK START

### 1. Clone Repository

```bash
git clone https://github.com/YOUR_USERNAME/vps-cloud-platform.git
cd vps-cloud-platform
```

### 2. Cài Đặt Backend

```bash
cd backend
npm install
cp .env.example .env
# Chỉnh sửa .env với thông tin Firebase
npm start
```

### 3. Mở Frontend

```bash
cd frontend
# Mở file index.html trong browser
# Hoặc dùng live server
```

### 4. Cấu Hình Firebase

1. Tạo Firebase project tại [console.firebase.google.com](https://console.firebase.google.com)
2. Download Service Account Key
3. Lưu vào `/firebase/serviceAccountKey.json`

### 5. Setup GitHub Actions

1. Push code lên GitHub
2. Thêm Secret: `FIREBASE_SERVICE_ACCOUNT`
3. Enable GitHub Actions

## 📁 CẤU TRÚC PROJECT

```
vps-cloud-platform/
├── vps-config.yml              # ⭐ CẤU HÌNH CHÍNH
├── frontend/                   # Frontend
│   ├── index.html
│   ├── dashboard.html
│   ├── create-vps.html
│   ├── css/
│   └── js/
├── backend/                    # Backend
│   ├── server.js
│   ├── config/
│   ├── routes/
│   └── controllers/
├── .github/workflows/          # GitHub Actions
│   └── create-vps.yml
├── firebase/                   # Firebase config
├── docs/                       # Documentation
│   ├── DEPLOYMENT.md
│   └── YAML_GUIDE.md
└── README.md
```

## ⚙️ CẤU HÌNH HỆ THỐNG

### File `vps-config.yml` - Single Source of Truth

Tất cả cấu hình hệ thống nằm trong file này:

```yaml
system:
  name: "VPS Cloud Vietnam"
  default_vps_duration_hours: 6
  max_vps_per_user: 3

vps_plans:
  basic:
    cpu_cores: 1
    ram_gb: 1
    points_per_6_hours: 60
  
  premium:
    cpu_cores: 4
    ram_gb: 8
    points_per_6_hours: 480
```

**Muốn thay đổi gì?**
1. Chỉnh file `vps-config.yml`
2. Commit & push
3. Hệ thống tự động cập nhật

## 🎮 SỬ DỤNG

### Tạo VPS Mới

1. Đăng nhập vào hệ thống
2. Chọn **"Tạo VPS"**
3. Chọn cấu hình (CPU, RAM, OS)
4. Click **"Tạo Ngay"**
5. VPS được triển khai trong 2-3 phút

### Kiếm Điểm

- **Xem quảng cáo**: +5 điểm (mỗi 5 phút)
- **Vượt link rút gọn**: +10 điểm (mỗi 10 phút)
- **Đăng nhập hàng ngày**: +20 điểm
- **Tạo VPS đầu tiên**: +50 điểm
- **Mời bạn bè**: +100 điểm

### Gia Hạn VPS

1. Vào **"Quản Lý VPS"**
2. Chọn VPS cần gia hạn
3. Click **"Gia Hạn"**
4. Chọn số giờ (có giảm giá khi gia hạn nhiều)

## 🛠️ CÔNG NGHỆ

### Frontend
- HTML5, CSS3, JavaScript (Vanilla)
- Responsive Design
- Font Awesome Icons

### Backend
- Node.js + Express
- Firebase Admin SDK
- JWT Authentication
- YAML Parser

### Database
- Firebase Firestore
- Real-time sync

### Infrastructure
- GitHub Actions (VPS Runner)
- Docker (VPS Container)
- Kami Tunnel (Public IP)

## 📚 TÀI LIỆU

- [📖 Hướng Dẫn Deployment](docs/DEPLOYMENT.md)
- [⚙️ Hướng Dẫn YAML](docs/YAML_GUIDE.md)
- [🔌 API Documentation](docs/API.md)

## 🔧 CHỈNH SỬA CẤU HÌNH

### Thay Đổi Điểm Gói VPS

```yaml
vps_plans:
  basic:
    points_per_6_hours: 50  # Giảm từ 60 → 50
```

### Tăng Giới Hạn CPU/RAM

```yaml
limits:
  cpu:
    max: 8                  # Tăng từ 4 → 8
  ram:
    max: 16                 # Tăng từ 8 → 16
```

### Thêm Gói VPS Mới

```yaml
vps_plans:
  enterprise:
    name: "Gói Doanh Nghiệp"
    cpu_cores: 8
    ram_gb: 16
    points_per_6_hours: 1200
```

👉 **Chi tiết**: Xem [YAML_GUIDE.md](docs/YAML_GUIDE.md)

## 🤝 ĐÓNG GÓP

Contributions are welcome! 

1. Fork project
2. Tạo branch mới (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Tạo Pull Request

## 📄 LICENSE

MIT License - xem [LICENSE](LICENSE) để biết chi tiết

## 👨‍💻 AUTHOR

**VPS Cloud Vietnam Team**

- Website: https://vpscloud.vn
- Email: support@vpscloud.vn
- GitHub: [@vpscloud](https://github.com/vpscloud)

## 🌟 ACKNOWLEDGMENTS

- [GitHub Actions](https://github.com/features/actions) - CI/CD Platform
- [Firebase](https://firebase.google.com) - Database & Auth
- [Docker](https://docker.com) - Containerization
- [Dockurr](https://github.com/dockur) - Windows Docker Images

## 📊 STATS

- ⭐ Stars: 0
- 🍴 Forks: 0
- 🐛 Issues: 0
- 📦 Version: 1.0.0

---

**Made with ❤️ in Vietnam 🇻🇳**

**Powered by GitHub Actions ⚡**
