# VPS CLOUD PLATFORM - CẤU TRÚC THƯ MỤC

```
vps-cloud-platform/
│
├── vps-config.yml              # ⭐ SINGLE SOURCE OF TRUTH
│
├── frontend/                   # Frontend (HTML/CSS/JS thuần)
│   ├── index.html             # Trang chủ
│   ├── login.html             # Đăng nhập
│   ├── register.html          # Đăng ký
│   ├── dashboard.html         # Bảng điều khiển
│   ├── create-vps.html        # Tạo VPS
│   ├── manage-vps.html        # Quản lý VPS
│   ├── earn-points.html       # Kiếm điểm
│   ├── settings.html          # Cài đặt
│   │
│   ├── css/
│   │   ├── main.css           # Style chính
│   │   ├── dashboard.css      # Style dashboard
│   │   └── components.css     # Components
│   │
│   └── js/
│       ├── config.js          # Cấu hình (đọc từ YAML)
│       ├── auth.js            # Xác thực
│       ├── api.js             # API calls
│       ├── dashboard.js       # Dashboard logic
│       ├── vps-manager.js     # Quản lý VPS
│       └── points.js          # Hệ thống điểm
│
├── backend/                    # Backend (Node.js)
│   ├── server.js              # Entry point
│   ├── package.json           # Dependencies
│   │
│   ├── config/
│   │   ├── firebase.js        # Firebase config
│   │   └── yaml-loader.js     # Đọc vps-config.yml
│   │
│   ├── routes/
│   │   ├── auth.js            # Routes đăng nhập
│   │   ├── vps.js             # Routes VPS
│   │   └── points.js          # Routes điểm
│   │
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── vpsController.js
│   │   └── pointsController.js
│   │
│   ├── services/
│   │   ├── githubActions.js   # Trigger GitHub Actions
│   │   ├── vpsService.js      # Logic VPS
│   │   └── pointsService.js   # Logic điểm
│   │
│   └── models/
│       ├── User.js
│       ├── VPS.js
│       └── Transaction.js
│
├── firebase/                   # Firebase config files
│   ├── serviceAccountKey.json # Service account (KHÔNG COMMIT)
│   └── firestore.rules        # Firestore rules
│
├── .github/workflows/          # GitHub Actions
│   ├── create-vps.yml         # Workflow tạo VPS
│   └── cleanup-vps.yml        # Workflow dọn dẹp
│
├── docs/                       # Tài liệu
│   ├── DEPLOYMENT.md          # Hướng dẫn deploy
│   ├── API.md                 # API documentation
│   └── YAML_GUIDE.md          # Hướng dẫn chỉnh YAML
│
├── .gitignore
├── README.md
└── package.json
```

## 🔑 FILE QUAN TRỌNG NHẤT

**vps-config.yml** - Tất cả cấu hình hệ thống nằm ở đây:
- Gói VPS (CPU, RAM, điểm)
- Hệ thống điểm thưởng
- Giới hạn hệ thống
- Cấu hình quảng cáo
- Firebase settings

**Muốn thay đổi gì → Chỉnh vps-config.yml → Push code → Hệ thống tự động cập nhật**
