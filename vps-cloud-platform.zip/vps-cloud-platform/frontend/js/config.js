/**
 * VPS CLOUD VIETNAM - CONFIGURATION LOADER
 * Đọc cấu hình từ vps-config.yml thông qua backend API
 */

const API_BASE_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:3000/api' 
    : '/api';

let cachedConfig = null;

/**
 * Load cấu hình từ backend (đã đọc từ YAML)
 */
async function loadConfig() {
    if (cachedConfig) {
        return cachedConfig;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/config`);
        if (!response.ok) {
            throw new Error('Failed to load configuration');
        }
        
        cachedConfig = await response.json();
        return cachedConfig;
    } catch (error) {
        console.error('Error loading config:', error);
        
        // Fallback config nếu không load được
        return {
            system: {
                name: "VPS Cloud Vietnam",
                version: "1.0.0",
                currency: "điểm",
                default_vps_duration_hours: 6,
                max_vps_per_user: 3
            },
            vps_plans: {
                basic: {
                    name: "Gói Cơ Bản",
                    cpu_cores: 1,
                    ram_gb: 1,
                    disk_gb: 20,
                    bandwidth_mbps: 100,
                    points_per_hour: 10,
                    points_per_6_hours: 60,
                    description: "Phù hợp cho website cá nhân, blog, học tập",
                    icon: "🌱"
                },
                standard: {
                    name: "Gói Tiêu Chuẩn",
                    cpu_cores: 2,
                    ram_gb: 2,
                    disk_gb: 40,
                    bandwidth_mbps: 200,
                    points_per_hour: 20,
                    points_per_6_hours: 120,
                    description: "Dành cho ứng dụng web, dự án cá nhân",
                    icon: "⚡"
                },
                professional: {
                    name: "Gói Chuyên Nghiệp",
                    cpu_cores: 4,
                    ram_gb: 4,
                    disk_gb: 80,
                    bandwidth_mbps: 500,
                    points_per_hour: 50,
                    points_per_6_hours: 300,
                    description: "Website thương mại, API server",
                    icon: "💼"
                },
                premium: {
                    name: "Gói Cao Cấp",
                    cpu_cores: 4,
                    ram_gb: 8,
                    disk_gb: 120,
                    bandwidth_mbps: 1000,
                    points_per_hour: 80,
                    points_per_6_hours: 480,
                    description: "Ứng dụng lớn, game server, machine learning",
                    icon: "👑"
                }
            }
        };
    }
}

/**
 * Tính điểm cần thiết dựa trên CPU và RAM tùy chỉnh
 */
function calculatePoints(cpuCores, ramGB, hours = 6) {
    const config = cachedConfig;
    if (!config || !config.custom_config) {
        // Fallback calculation
        const basePoints = 10;
        const cpuMultiplier = cpuCores;
        const ramMultiplier = ramGB * 0.5 + 0.5;
        return Math.ceil(basePoints * cpuMultiplier * ramMultiplier * hours);
    }
    
    const { base_points_per_hour, cpu_options, ram_options } = config.custom_config;
    
    // Tìm multiplier cho CPU
    const cpuOption = cpu_options.find(opt => opt.cores === cpuCores);
    const cpuMultiplier = cpuOption ? cpuOption.multiplier : 1.0;
    
    // Tìm multiplier cho RAM
    const ramOption = ram_options.find(opt => opt.size_gb === ramGB);
    const ramMultiplier = ramOption ? ramOption.multiplier : 1.0;
    
    // Tính điểm theo công thức
    const pointsPerHour = base_points_per_hour * cpuMultiplier * ramMultiplier;
    return Math.ceil(pointsPerHour * hours);
}

/**
 * Format số điểm với dấu phẩy
 */
function formatPoints(points) {
    return points.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Format thời gian còn lại
 */
function formatTimeRemaining(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else if (minutes > 0) {
        return `${minutes}m ${secs}s`;
    } else {
        return `${secs}s`;
    }
}

/**
 * Kiểm tra người dùng đã đăng nhập
 */
function isAuthenticated() {
    return localStorage.getItem('vps_user_token') !== null;
}

/**
 * Lấy thông tin người dùng từ localStorage
 */
function getCurrentUser() {
    const userJson = localStorage.getItem('vps_user_data');
    return userJson ? JSON.parse(userJson) : null;
}

/**
 * Lưu thông tin người dùng
 */
function saveUser(userData) {
    localStorage.setItem('vps_user_data', JSON.stringify(userData));
    if (userData.token) {
        localStorage.setItem('vps_user_token', userData.token);
    }
}

/**
 * Đăng xuất
 */
function logout() {
    localStorage.removeItem('vps_user_data');
    localStorage.removeItem('vps_user_token');
    window.location.href = 'login.html';
}

/**
 * Redirect nếu chưa đăng nhập
 */
function requireAuth() {
    if (!isAuthenticated()) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#0066cc'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Export functions
window.loadConfig = loadConfig;
window.calculatePoints = calculatePoints;
window.formatPoints = formatPoints;
window.formatTimeRemaining = formatTimeRemaining;
window.isAuthenticated = isAuthenticated;
window.getCurrentUser = getCurrentUser;
window.saveUser = saveUser;
window.logout = logout;
window.requireAuth = requireAuth;
window.showToast = showToast;
window.API_BASE_URL = API_BASE_URL;
