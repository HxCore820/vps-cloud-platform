/**
 * GITHUB ACTIONS SERVICE
 * Trigger GitHub Actions workflows từ backend
 */

const axios = require('axios');

// GitHub Configuration
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_OWNER = process.env.GITHUB_OWNER || 'your-username';
const GITHUB_REPO = process.env.GITHUB_REPO || 'vps-cloud-platform';
const WORKFLOW_ID = 'create-vps.yml';

/**
 * Trigger workflow tạo VPS
 */
async function triggerCreateVPS(inputs) {
    if (!GITHUB_TOKEN) {
        console.warn('⚠️  GITHUB_TOKEN not set. Skipping GitHub Actions trigger.');
        console.log('   VPS will be created in mock mode.');
        return { success: true, mode: 'mock' };
    }
    
    try {
        const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/workflows/${WORKFLOW_ID}/dispatches`;
        
        const response = await axios.post(
            url,
            {
                ref: 'main',
                inputs: inputs
            },
            {
                headers: {
                    'Authorization': `Bearer ${GITHUB_TOKEN}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'Content-Type': 'application/json'
                }
            }
        );
        
        console.log(`✅ GitHub Actions triggered successfully`);
        console.log(`   - Workflow: ${WORKFLOW_ID}`);
        console.log(`   - VPS ID: ${inputs.vps_id}`);
        console.log(`   - Config: ${inputs.cpu_cores} CPU, ${inputs.ram_gb} GB RAM`);
        
        return {
            success: true,
            mode: 'production',
            workflow: WORKFLOW_ID
        };
        
    } catch (error) {
        console.error('❌ Failed to trigger GitHub Actions:', error.message);
        
        if (error.response) {
            console.error('   Status:', error.response.status);
            console.error('   Data:', error.response.data);
        }
        
        throw new Error('Cannot trigger GitHub Actions workflow');
    }
}

/**
 * Kiểm tra trạng thái workflow
 */
async function getWorkflowStatus(runId) {
    if (!GITHUB_TOKEN) {
        return { status: 'mock' };
    }
    
    try {
        const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/runs/${runId}`;
        
        const response = await axios.get(url, {
            headers: {
                'Authorization': `Bearer ${GITHUB_TOKEN}`,
                'Accept': 'application/vnd.github.v3+json'
            }
        });
        
        return {
            id: response.data.id,
            status: response.data.status,
            conclusion: response.data.conclusion,
            created_at: response.data.created_at,
            updated_at: response.data.updated_at,
            html_url: response.data.html_url
        };
        
    } catch (error) {
        console.error('Error getting workflow status:', error.message);
        throw error;
    }
}

/**
 * List các workflow runs
 */
async function listWorkflowRuns(limit = 10) {
    if (!GITHUB_TOKEN) {
        return { runs: [] };
    }
    
    try {
        const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/workflows/${WORKFLOW_ID}/runs?per_page=${limit}`;
        
        const response = await axios.get(url, {
            headers: {
                'Authorization': `Bearer ${GITHUB_TOKEN}`,
                'Accept': 'application/vnd.github.v3+json'
            }
        });
        
        return {
            total_count: response.data.total_count,
            runs: response.data.workflow_runs.map(run => ({
                id: run.id,
                name: run.name,
                status: run.status,
                conclusion: run.conclusion,
                created_at: run.created_at,
                html_url: run.html_url
            }))
        };
        
    } catch (error) {
        console.error('Error listing workflows:', error.message);
        throw error;
    }
}

/**
 * Cancel workflow run
 */
async function cancelWorkflow(runId) {
    if (!GITHUB_TOKEN) {
        return { success: true, mode: 'mock' };
    }
    
    try {
        const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/runs/${runId}/cancel`;
        
        await axios.post(url, {}, {
            headers: {
                'Authorization': `Bearer ${GITHUB_TOKEN}`,
                'Accept': 'application/vnd.github.v3+json'
            }
        });
        
        console.log(`✅ Workflow cancelled: ${runId}`);
        return { success: true };
        
    } catch (error) {
        console.error('Error cancelling workflow:', error.message);
        throw error;
    }
}

module.exports = {
    triggerCreateVPS,
    getWorkflowStatus,
    listWorkflowRuns,
    cancelWorkflow
};
