/**
 * VPS SERVICE
 * Helper functions cho VPS management
 */

const { db, COLLECTIONS } = require('../config/firebase');

/**
 * Đếm số VPS đang hoạt động của user
 */
async function getActiveVPSCount(userId) {
    const snapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
        .where('user_id', '==', userId)
        .where('status', 'in', ['running', 'provisioning', 'creating'])
        .get();
    
    return snapshot.size;
}

/**
 * Tính tổng CPU đang sử dụng
 */
async function getTotalCPU(userId) {
    const snapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
        .where('user_id', '==', userId)
        .where('status', 'in', ['running', 'provisioning'])
        .get();
    
    let totalCPU = 0;
    snapshot.forEach(doc => {
        const data = doc.data();
        totalCPU += data.cpu_cores || 0;
    });
    
    return totalCPU;
}

/**
 * Tính tổng RAM đang sử dụng
 */
async function getTotalRAM(userId) {
    const snapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
        .where('user_id', '==', userId)
        .where('status', 'in', ['running', 'provisioning'])
        .get();
    
    let totalRAM = 0;
    snapshot.forEach(doc => {
        const data = doc.data();
        totalRAM += data.ram_gb || 0;
    });
    
    return totalRAM;
}

/**
 * Kiểm tra VPS đã hết hạn
 */
async function checkExpiredVPS() {
    const now = new Date();
    
    const snapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
        .where('status', '==', 'running')
        .where('expires_at', '<=', now)
        .get();
    
    const expiredVPS = [];
    
    for (const doc of snapshot.docs) {
        const vpsData = doc.data();
        
        // Update status
        await db.collection(COLLECTIONS.VPS_INSTANCES).doc(doc.id).update({
            status: 'expired',
            expired_at: now
        });
        
        expiredVPS.push({
            vps_id: doc.id,
            user_id: vpsData.user_id
        });
        
        console.log(`⏰ VPS expired: ${doc.id}`);
    }
    
    return expiredVPS;
}

/**
 * Lấy thống kê VPS của user
 */
async function getUserStats(userId) {
    // VPS đang chạy
    const activeCount = await getActiveVPSCount(userId);
    
    // Tổng CPU/RAM
    const totalCPU = await getTotalCPU(userId);
    const totalRAM = await getTotalRAM(userId);
    
    // Tổng số VPS đã tạo
    const allVPSSnapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
        .where('user_id', '==', userId)
        .get();
    
    // Tổng điểm đã tiêu
    const transactionsSnapshot = await db.collection(COLLECTIONS.TRANSACTIONS)
        .where('user_id', '==', userId)
        .where('type', '==', 'create_vps')
        .get();
    
    let totalPointsSpent = 0;
    transactionsSnapshot.forEach(doc => {
        const data = doc.data();
        totalPointsSpent += data.points_spent || 0;
    });
    
    // Tổng giờ sử dụng
    let totalHours = 0;
    allVPSSnapshot.forEach(doc => {
        const data = doc.data();
        totalHours += data.duration_hours || 0;
    });
    
    return {
        active_vps: activeCount,
        total_vps: allVPSSnapshot.size,
        total_cpu: totalCPU,
        total_ram: totalRAM,
        total_points_spent: totalPointsSpent,
        total_hours: totalHours
    };
}

/**
 * Validate tài nguyên VPS
 */
async function validateResources(userId, cpuCores, ramGB, config) {
    const totalCPU = await getTotalCPU(userId);
    const totalRAM = await getTotalRAM(userId);
    
    // Kiểm tra tổng CPU
    if (totalCPU + cpuCores > config.limits.max_total_cpu) {
        throw new Error(
            `Vượt quá giới hạn tổng CPU (${config.limits.max_total_cpu} cores). ` +
            `Hiện tại: ${totalCPU}, yêu cầu thêm: ${cpuCores}`
        );
    }
    
    // Kiểm tra tổng RAM
    if (totalRAM + ramGB > config.limits.max_total_ram) {
        throw new Error(
            `Vượt quá giới hạn tổng RAM (${config.limits.max_total_ram} GB). ` +
            `Hiện tại: ${totalRAM} GB, yêu cầu thêm: ${ramGB} GB`
        );
    }
    
    return true;
}

module.exports = {
    getActiveVPSCount,
    getTotalCPU,
    getTotalRAM,
    checkExpiredVPS,
    getUserStats,
    validateResources
};
