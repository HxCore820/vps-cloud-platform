/**
 * YAML CONFIGURATION LOADER
 * Đọc vps-config.yml và cung cấp cho toàn bộ hệ thống
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

let cachedConfig = null;

function loadConfig() {
    if (cachedConfig) {
        return cachedConfig;
    }

    try {
        // Đường dẫn đến file vps-config.yml
        const configPath = path.join(__dirname, '../../vps-config.yml');
        
        // Đọc file YAML
        const fileContents = fs.readFileSync(configPath, 'utf8');
        
        // Parse YAML thành object
        cachedConfig = yaml.load(fileContents);
        
        console.log('✅ Đã load cấu hình từ vps-config.yml');
        console.log(`   - Hệ thống: ${cachedConfig.system.name}`);
        console.log(`   - Version: ${cachedConfig.system.version}`);
        console.log(`   - Số gói VPS: ${Object.keys(cachedConfig.vps_plans).length}`);
        
        return cachedConfig;
    } catch (error) {
        console.error('❌ Lỗi khi load config từ YAML:', error.message);
        
        // Fallback config cơ bản
        console.warn('⚠️  Sử dụng cấu hình mặc định (fallback)');
        cachedConfig = {
            system: {
                name: "VPS Cloud Vietnam",
                version: "1.0.0",
                currency: "điểm",
                default_vps_duration_hours: 6,
                max_vps_per_user: 3
            },
            vps_plans: {},
            limits: {
                cpu: { min: 1, max: 4 },
                ram: { min: 1, max: 8 }
            }
        };
        
        return cachedConfig;
    }
}

/**
 * Reload config (dùng khi update YAML file)
 */
function reloadConfig() {
    cachedConfig = null;
    return loadConfig();
}

/**
 * Tính điểm dựa trên CPU và RAM
 */
function calculatePoints(cpuCores, ramGB, hours = 6) {
    const config = loadConfig();
    
    if (!config.custom_config) {
        // Fallback calculation
        const basePoints = 10;
        const cpuMultiplier = cpuCores;
        const ramMultiplier = ramGB * 0.5 + 0.5;
        return Math.ceil(basePoints * cpuMultiplier * ramMultiplier * hours);
    }
    
    const { base_points_per_hour, cpu_options, ram_options } = config.custom_config;
    
    // Tìm multiplier cho CPU
    const cpuOption = cpu_options.find(opt => opt.cores === cpuCores);
    const cpuMultiplier = cpuOption ? cpuOption.multiplier : 1.0;
    
    // Tìm multiplier cho RAM
    const ramOption = ram_options.find(opt => opt.size_gb === ramGB);
    const ramMultiplier = ramOption ? ramOption.multiplier : 1.0;
    
    // Tính điểm theo công thức trong YAML
    const pointsPerHour = base_points_per_hour * cpuMultiplier * ramMultiplier;
    return Math.ceil(pointsPerHour * hours);
}

/**
 * Validate cấu hình VPS
 */
function validateVPSConfig(cpuCores, ramGB) {
    const config = loadConfig();
    const limits = config.limits;
    
    if (cpuCores < limits.cpu.min || cpuCores > limits.cpu.max) {
        throw new Error(`CPU phải từ ${limits.cpu.min} đến ${limits.cpu.max} cores`);
    }
    
    if (ramGB < limits.ram.min || ramGB > limits.ram.max) {
        throw new Error(`RAM phải từ ${limits.ram.min} đến ${limits.ram.max} GB`);
    }
    
    return true;
}

module.exports = {
    loadConfig,
    reloadConfig,
    calculatePoints,
    validateVPSConfig
};
