/**
 * FIREBASE CONFIGURATION
 * Khởi tạo Firebase Admin SDK
 */

const admin = require('firebase-admin');
const path = require('path');

// Đọc service account key
let serviceAccount;

try {
    // Thử đọc từ file
    serviceAccount = require(path.join(__dirname, '../../firebase/serviceAccountKey.json'));
} catch (error) {
    console.warn('⚠️  Không tìm thấy serviceAccountKey.json');
    
    // Thử đọc từ environment variable (để deploy)
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
        serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    } else {
        console.error('❌ Chưa cấu hình Firebase Service Account');
        console.log('   Hướng dẫn:');
        console.log('   1. Tạo Service Account tại: https://console.firebase.google.com');
        console.log('   2. Download JSON key');
        console.log('   3. Lưu vào: firebase/serviceAccountKey.json');
        console.log('   4. Hoặc set environment variable: FIREBASE_SERVICE_ACCOUNT');
    }
}

// Khởi tạo Firebase Admin
if (serviceAccount) {
    try {
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            databaseURL: process.env.FIREBASE_DATABASE_URL
        });
        
        console.log('✅ Firebase Admin initialized successfully');
    } catch (error) {
        console.error('❌ Lỗi khởi tạo Firebase:', error.message);
    }
}

// Export Firestore instance
const db = admin.firestore();

// Collection names từ YAML config
const COLLECTIONS = {
    USERS: 'users',
    VPS_INSTANCES: 'vps_instances',
    POINTS_HISTORY: 'points_history',
    TRANSACTIONS: 'transactions'
};

module.exports = {
    admin,
    db,
    COLLECTIONS
};
