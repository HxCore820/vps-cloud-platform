/**
 * VPS ROUTES
 * API endpoints cho quản lý VPS
 */

const express = require('express');
const router = express.Router();
const vpsController = require('../controllers/vpsController');

// Middleware xác thực (giả định)
const authenticate = (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    // TODO: Verify JWT token
    req.userId = 'user123'; // Mock user ID
    next();
};

// GET /api/vps - Lấy danh sách VPS của user
router.get('/', authenticate, vpsController.getUserVPS);

// GET /api/vps/:id - Lấy thông tin 1 VPS
router.get('/:id', authenticate, vpsController.getVPSById);

// POST /api/vps/create - Tạo VPS mới
router.post('/create', authenticate, vpsController.createVPS);

// POST /api/vps/:id/extend - Gia hạn VPS
router.post('/:id/extend', authenticate, vpsController.extendVPS);

// DELETE /api/vps/:id - Xóa VPS
router.delete('/:id', authenticate, vpsController.deleteVPS);

// POST /api/vps/:id/start - Start VPS
router.post('/:id/start', authenticate, vpsController.startVPS);

// POST /api/vps/:id/stop - Stop VPS
router.post('/:id/stop', authenticate, vpsController.stopVPS);

// POST /api/vps/:id/restart - Restart VPS
router.post('/:id/restart', authenticate, vpsController.restartVPS);

module.exports = router;
