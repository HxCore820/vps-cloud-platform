/**
 * POINTS ROUTES
 * API endpoints cho hệ thống điểm
 */

const express = require('express');
const router = express.Router();
const pointsController = require('../controllers/pointsController');

// Middleware xác thực
const authenticate = (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    req.userId = 'user123'; // Mock
    next();
};

// GET /api/points/balance - Lấy số điểm hiện tại
router.get('/balance', authenticate, pointsController.getBalance);

// GET /api/points/history - Lịch sử điểm
router.get('/history', authenticate, pointsController.getHistory);

// POST /api/points/earn/watch-ad - Xem quảng cáo
router.post('/earn/watch-ad', authenticate, pointsController.earnFromAd);

// POST /api/points/earn/shortlink - Vượt link rút gọn
router.post('/earn/shortlink', authenticate, pointsController.earnFromShortlink);

// POST /api/points/earn/daily-mission - Hoàn thành nhiệm vụ
router.post('/earn/daily-mission', authenticate, pointsController.completeDailyMission);

module.exports = router;
