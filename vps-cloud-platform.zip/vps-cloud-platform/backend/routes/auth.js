/**
 * AUTH ROUTES
 * API endpoints cho xác thực
 */

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// POST /api/auth/register - Đăng ký
router.post('/register', authController.register);

// POST /api/auth/login - Đăng nhập
router.post('/login', authController.login);

// POST /api/auth/logout - Đăng xuất
router.post('/logout', authController.logout);

// GET /api/auth/me - Lấy thông tin user hiện tại
router.get('/me', authController.getCurrentUser);

module.exports = router;
