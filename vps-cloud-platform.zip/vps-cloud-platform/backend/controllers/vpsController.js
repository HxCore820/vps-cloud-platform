/**
 * VPS CONTROLLER
 * Logic xử lý các thao tác VPS
 */

const { db, COLLECTIONS } = require('../config/firebase');
const yamlLoader = require('../config/yaml-loader');
const githubActions = require('../services/githubActions');
const vpsService = require('../services/vpsService');

/**
 * Lấy danh sách VPS của user
 */
exports.getUserVPS = async (req, res) => {
    try {
        const userId = req.userId;
        
        const snapshot = await db.collection(COLLECTIONS.VPS_INSTANCES)
            .where('user_id', '==', userId)
            .orderBy('created_at', 'desc')
            .get();
        
        const vpsList = [];
        snapshot.forEach(doc => {
            vpsList.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        res.json({
            success: true,
            count: vpsList.length,
            data: vpsList
        });
    } catch (error) {
        console.error('Error getting VPS list:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Lấy thông tin 1 VPS
 */
exports.getVPSById = async (req, res) => {
    try {
        const vpsId = req.params.id;
        const userId = req.userId;
        
        const doc = await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).get();
        
        if (!doc.exists) {
            return res.status(404).json({ error: 'VPS not found' });
        }
        
        const vpsData = doc.data();
        
        // Kiểm tra quyền sở hữu
        if (vpsData.user_id !== userId) {
            return res.status(403).json({ error: 'Forbidden' });
        }
        
        res.json({
            success: true,
            data: {
                id: doc.id,
                ...vpsData
            }
        });
    } catch (error) {
        console.error('Error getting VPS:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Tạo VPS mới
 */
exports.createVPS = async (req, res) => {
    try {
        const userId = req.userId;
        const { cpu_cores, ram_gb, os_type, duration_hours } = req.body;
        
        // Load config từ YAML
        const config = yamlLoader.loadConfig();
        
        // 1. Validate input
        try {
            yamlLoader.validateVPSConfig(cpu_cores, ram_gb);
        } catch (error) {
            return res.status(400).json({ error: error.message });
        }
        
        // 2. Kiểm tra số VPS đang hoạt động
        const activeCount = await vpsService.getActiveVPSCount(userId);
        if (activeCount >= config.system.max_vps_per_user) {
            return res.status(400).json({
                error: `Bạn đã đạt giới hạn ${config.system.max_vps_per_user} VPS`
            });
        }
        
        // 3. Tính điểm cần thiết
        const hours = duration_hours || config.system.default_vps_duration_hours;
        const pointsRequired = yamlLoader.calculatePoints(cpu_cores, ram_gb, hours);
        
        // 4. Kiểm tra điểm của user
        const userDoc = await db.collection(COLLECTIONS.USERS).doc(userId).get();
        const userData = userDoc.data();
        
        if (userData.points < pointsRequired) {
            return res.status(400).json({
                error: `Không đủ điểm. Cần ${pointsRequired} điểm, bạn có ${userData.points} điểm`
            });
        }
        
        // 5. Trừ điểm
        await db.collection(COLLECTIONS.USERS).doc(userId).update({
            points: userData.points - pointsRequired
        });
        
        // 6. Tạo VPS record trong Firestore
        const vpsId = `vps_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const vpsData = {
            vps_id: vpsId,
            user_id: userId,
            cpu_cores: cpu_cores,
            ram_gb: ram_gb,
            os_type: os_type,
            duration_hours: hours,
            points_spent: pointsRequired,
            status: 'creating',
            created_at: new Date(),
            expires_at: new Date(Date.now() + hours * 3600000)
        };
        
        await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).set(vpsData);
        
        // 7. Lưu transaction
        await db.collection(COLLECTIONS.TRANSACTIONS).add({
            user_id: userId,
            vps_id: vpsId,
            type: 'create_vps',
            points_spent: pointsRequired,
            timestamp: new Date()
        });
        
        // 8. Trigger GitHub Actions để tạo VPS thực
        try {
            await githubActions.triggerCreateVPS({
                vps_id: vpsId,
                user_id: userId,
                cpu_cores: cpu_cores.toString(),
                ram_gb: ram_gb.toString(),
                os_type: os_type,
                duration_hours: hours.toString()
            });
            
            // Update status
            await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).update({
                status: 'provisioning'
            });
            
            console.log(`✅ Triggered GitHub Actions for VPS: ${vpsId}`);
        } catch (error) {
            console.error('❌ Failed to trigger GitHub Actions:', error);
            
            // Rollback: Hoàn điểm
            await db.collection(COLLECTIONS.USERS).doc(userId).update({
                points: userData.points
            });
            
            // Xóa VPS record
            await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).delete();
            
            throw new Error('Không thể tạo VPS. Vui lòng thử lại sau.');
        }
        
        res.json({
            success: true,
            message: 'VPS đang được tạo',
            data: {
                vps_id: vpsId,
                points_spent: pointsRequired,
                estimated_time: '2-3 phút'
            }
        });
        
    } catch (error) {
        console.error('Error creating VPS:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Gia hạn VPS
 */
exports.extendVPS = async (req, res) => {
    try {
        const vpsId = req.params.id;
        const userId = req.userId;
        const { hours } = req.body;
        
        if (!hours || hours <= 0) {
            return res.status(400).json({ error: 'Invalid hours' });
        }
        
        // Lấy thông tin VPS
        const vpsDoc = await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).get();
        
        if (!vpsDoc.exists) {
            return res.status(404).json({ error: 'VPS not found' });
        }
        
        const vpsData = vpsDoc.data();
        
        if (vpsData.user_id !== userId) {
            return res.status(403).json({ error: 'Forbidden' });
        }
        
        // Tính điểm cần thiết
        const pointsRequired = yamlLoader.calculatePoints(
            vpsData.cpu_cores,
            vpsData.ram_gb,
            hours
        );
        
        // Áp dụng discount nếu có
        const config = yamlLoader.loadConfig();
        let discount = 1.0;
        if (config.extension.discount_bulk) {
            if (hours >= 12 && config.extension.discount_bulk['12_hours']) {
                discount = config.extension.discount_bulk['12_hours'];
            } else if (hours >= 6 && config.extension.discount_bulk['6_hours']) {
                discount = config.extension.discount_bulk['6_hours'];
            }
        }
        
        const finalPoints = Math.ceil(pointsRequired * discount);
        
        // Kiểm tra điểm
        const userDoc = await db.collection(COLLECTIONS.USERS).doc(userId).get();
        const userData = userDoc.data();
        
        if (userData.points < finalPoints) {
            return res.status(400).json({
                error: `Không đủ điểm. Cần ${finalPoints} điểm`
            });
        }
        
        // Trừ điểm và gia hạn
        await db.collection(COLLECTIONS.USERS).doc(userId).update({
            points: userData.points - finalPoints
        });
        
        const newExpiresAt = new Date(vpsData.expires_at.toDate().getTime() + hours * 3600000);
        
        await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).update({
            expires_at: newExpiresAt
        });
        
        // Lưu transaction
        await db.collection(COLLECTIONS.TRANSACTIONS).add({
            user_id: userId,
            vps_id: vpsId,
            type: 'extend_vps',
            hours: hours,
            points_spent: finalPoints,
            discount: discount < 1.0 ? Math.round((1 - discount) * 100) : 0,
            timestamp: new Date()
        });
        
        res.json({
            success: true,
            message: `Đã gia hạn VPS thêm ${hours} giờ`,
            data: {
                points_spent: finalPoints,
                discount: discount < 1.0 ? Math.round((1 - discount) * 100) : 0,
                new_expires_at: newExpiresAt
            }
        });
        
    } catch (error) {
        console.error('Error extending VPS:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Xóa VPS
 */
exports.deleteVPS = async (req, res) => {
    try {
        const vpsId = req.params.id;
        const userId = req.userId;
        
        const vpsDoc = await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).get();
        
        if (!vpsDoc.exists) {
            return res.status(404).json({ error: 'VPS not found' });
        }
        
        const vpsData = vpsDoc.data();
        
        if (vpsData.user_id !== userId) {
            return res.status(403).json({ error: 'Forbidden' });
        }
        
        // Update status
        await db.collection(COLLECTIONS.VPS_INSTANCES).doc(vpsId).update({
            status: 'deleted',
            deleted_at: new Date()
        });
        
        // TODO: Trigger GitHub Actions để stop VPS container
        
        res.json({
            success: true,
            message: 'VPS đã được xóa'
        });
        
    } catch (error) {
        console.error('Error deleting VPS:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Start VPS
 */
exports.startVPS = async (req, res) => {
    res.json({ message: 'Start VPS - Coming soon' });
};

/**
 * Stop VPS
 */
exports.stopVPS = async (req, res) => {
    res.json({ message: 'Stop VPS - Coming soon' });
};

/**
 * Restart VPS
 */
exports.restartVPS = async (req, res) => {
    res.json({ message: 'Restart VPS - Coming soon' });
};
