/**
 * AUTH CONTROLLER
 * Xử lý đăng ký, đăng nhập, xác thực
 */

const { db, COLLECTIONS } = require('../config/firebase');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const yamlLoader = require('../config/yaml-loader');

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

/**
 * Đăng ký user mới
 */
exports.register = async (req, res) => {
    try {
        const { email, password, name } = req.body;
        
        // Validate input
        if (!email || !password || !name) {
            return res.status(400).json({
                error: 'Email, password và name là bắt buộc'
            });
        }
        
        // Kiểm tra email đã tồn tại
        const existingUser = await db.collection(COLLECTIONS.USERS)
            .where('email', '==', email)
            .get();
        
        if (!existingUser.empty) {
            return res.status(400).json({
                error: 'Email đã được sử dụng'
            });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Load config để lấy initial points
        const config = yamlLoader.loadConfig();
        const initialPoints = config.points_system.initial_points;
        
        // Tạo user mới
        const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const userData = {
            user_id: userId,
            email: email,
            name: name,
            password: hashedPassword,
            points: initialPoints,
            created_at: new Date(),
            last_login: new Date()
        };
        
        await db.collection(COLLECTIONS.USERS).doc(userId).set(userData);
        
        // Tạo JWT token
        const token = jwt.sign(
            { userId: userId, email: email },
            JWT_SECRET,
            { expiresIn: '7d' }
        );
        
        res.json({
            success: true,
            message: 'Đăng ký thành công',
            data: {
                user_id: userId,
                email: email,
                name: name,
                points: initialPoints,
                token: token
            }
        });
        
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Đăng nhập
 */
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({
                error: 'Email và password là bắt buộc'
            });
        }
        
        // Tìm user theo email
        const snapshot = await db.collection(COLLECTIONS.USERS)
            .where('email', '==', email)
            .get();
        
        if (snapshot.empty) {
            return res.status(401).json({
                error: 'Email hoặc password không đúng'
            });
        }
        
        const userDoc = snapshot.docs[0];
        const userData = userDoc.data();
        
        // Verify password
        const isValidPassword = await bcrypt.compare(password, userData.password);
        
        if (!isValidPassword) {
            return res.status(401).json({
                error: 'Email hoặc password không đúng'
            });
        }
        
        // Update last login
        await db.collection(COLLECTIONS.USERS).doc(userDoc.id).update({
            last_login: new Date()
        });
        
        // Tạo JWT token
        const token = jwt.sign(
            { userId: userDoc.id, email: userData.email },
            JWT_SECRET,
            { expiresIn: '7d' }
        );
        
        res.json({
            success: true,
            message: 'Đăng nhập thành công',
            data: {
                user_id: userDoc.id,
                email: userData.email,
                name: userData.name,
                points: userData.points,
                token: token
            }
        });
        
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Đăng xuất
 */
exports.logout = async (req, res) => {
    res.json({
        success: true,
        message: 'Đăng xuất thành công'
    });
};

/**
 * Lấy thông tin user hiện tại
 */
exports.getCurrentUser = async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (!token) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        
        // Verify token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Lấy thông tin user
        const userDoc = await db.collection(COLLECTIONS.USERS).doc(decoded.userId).get();
        
        if (!userDoc.exists) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userData = userDoc.data();
        
        // Không trả password
        delete userData.password;
        
        res.json({
            success: true,
            data: {
                user_id: userDoc.id,
                ...userData
            }
        });
        
    } catch (error) {
        console.error('Error getting current user:', error);
        res.status(401).json({ error: 'Invalid token' });
    }
};
