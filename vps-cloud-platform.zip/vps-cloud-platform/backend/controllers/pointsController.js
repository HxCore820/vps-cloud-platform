/**
 * POINTS CONTROLLER
 * Xử lý kiếm điểm, lịch sử điểm
 */

const { db, COLLECTIONS } = require('../config/firebase');
const yamlLoader = require('../config/yaml-loader');

/**
 * Lấy số điểm hiện tại
 */
exports.getBalance = async (req, res) => {
    try {
        const userId = req.userId;
        
        const userDoc = await db.collection(COLLECTIONS.USERS).doc(userId).get();
        
        if (!userDoc.exists) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const userData = userDoc.data();
        
        res.json({
            success: true,
            data: {
                points: userData.points || 0
            }
        });
        
    } catch (error) {
        console.error('Error getting balance:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Lấy lịch sử điểm
 */
exports.getHistory = async (req, res) => {
    try {
        const userId = req.userId;
        const limit = parseInt(req.query.limit) || 50;
        
        const snapshot = await db.collection(COLLECTIONS.POINTS_HISTORY)
            .where('user_id', '==', userId)
            .orderBy('timestamp', 'desc')
            .limit(limit)
            .get();
        
        const history = [];
        snapshot.forEach(doc => {
            history.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        res.json({
            success: true,
            count: history.length,
            data: history
        });
        
    } catch (error) {
        console.error('Error getting history:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Kiếm điểm từ xem quảng cáo
 */
exports.earnFromAd = async (req, res) => {
    try {
        const userId = req.userId;
        
        // Load config từ YAML
        const config = yamlLoader.loadConfig();
        const adConfig = config.points_system.watch_ad;
        
        // Kiểm tra cooldown
        const lastAdTime = await getLastAction(userId, 'watch_ad');
        const now = Date.now();
        
        if (lastAdTime) {
            const timeSinceLastAd = now - lastAdTime;
            const cooldownMs = adConfig.cooldown_minutes * 60 * 1000;
            
            if (timeSinceLastAd < cooldownMs) {
                const remainingSeconds = Math.ceil((cooldownMs - timeSinceLastAd) / 1000);
                return res.status(429).json({
                    error: `Vui lòng chờ ${remainingSeconds} giây trước khi xem quảng cáo tiếp theo`
                });
            }
        }
        
        // Kiểm tra giới hạn hàng ngày
        const todayCount = await getTodayCount(userId, 'watch_ad');
        
        if (todayCount >= adConfig.max_per_day) {
            return res.status(429).json({
                error: `Bạn đã đạt giới hạn ${adConfig.max_per_day} quảng cáo mỗi ngày`
            });
        }
        
        // Cộng điểm
        const pointsToAdd = adConfig.points_reward;
        
        await addPoints(userId, pointsToAdd, 'watch_ad', 'Xem quảng cáo');
        
        // Lưu last action
        await setLastAction(userId, 'watch_ad', now);
        
        res.json({
            success: true,
            message: `Bạn đã nhận ${pointsToAdd} điểm từ xem quảng cáo`,
            data: {
                points_earned: pointsToAdd,
                remaining_today: adConfig.max_per_day - todayCount - 1
            }
        });
        
    } catch (error) {
        console.error('Error earning from ad:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Kiếm điểm từ vượt link rút gọn
 */
exports.earnFromShortlink = async (req, res) => {
    try {
        const userId = req.userId;
        
        const config = yamlLoader.loadConfig();
        const shortlinkConfig = config.points_system.shortlink;
        
        // Kiểm tra cooldown
        const lastTime = await getLastAction(userId, 'shortlink');
        const now = Date.now();
        
        if (lastTime) {
            const timeSince = now - lastTime;
            const cooldownMs = shortlinkConfig.cooldown_minutes * 60 * 1000;
            
            if (timeSince < cooldownMs) {
                const remainingSeconds = Math.ceil((cooldownMs - timeSince) / 1000);
                return res.status(429).json({
                    error: `Vui lòng chờ ${remainingSeconds} giây`
                });
            }
        }
        
        // Kiểm tra giới hạn
        const todayCount = await getTodayCount(userId, 'shortlink');
        
        if (todayCount >= shortlinkConfig.max_per_day) {
            return res.status(429).json({
                error: `Bạn đã đạt giới hạn ${shortlinkConfig.max_per_day} lượt mỗi ngày`
            });
        }
        
        // Cộng điểm
        const pointsToAdd = shortlinkConfig.points_reward;
        
        await addPoints(userId, pointsToAdd, 'shortlink', 'Vượt link rút gọn');
        await setLastAction(userId, 'shortlink', now);
        
        res.json({
            success: true,
            message: `Bạn đã nhận ${pointsToAdd} điểm`,
            data: {
                points_earned: pointsToAdd,
                remaining_today: shortlinkConfig.max_per_day - todayCount - 1
            }
        });
        
    } catch (error) {
        console.error('Error earning from shortlink:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * Hoàn thành nhiệm vụ hằng ngày
 */
exports.completeDailyMission = async (req, res) => {
    try {
        const userId = req.userId;
        const { mission_id } = req.body;
        
        if (!mission_id) {
            return res.status(400).json({ error: 'mission_id is required' });
        }
        
        const config = yamlLoader.loadConfig();
        const missions = config.points_system.daily_missions;
        
        const mission = missions[mission_id];
        
        if (!mission) {
            return res.status(404).json({ error: 'Mission not found' });
        }
        
        // Kiểm tra đã hoàn thành chưa
        const completed = await hasMissionCompleted(userId, mission_id);
        
        if (completed) {
            return res.status(400).json({
                error: 'Bạn đã hoàn thành nhiệm vụ này rồi'
            });
        }
        
        // Cộng điểm
        const pointsToAdd = mission.points;
        
        await addPoints(userId, pointsToAdd, 'daily_mission', mission.description);
        await markMissionCompleted(userId, mission_id);
        
        res.json({
            success: true,
            message: `Hoàn thành nhiệm vụ: ${mission.description}`,
            data: {
                points_earned: pointsToAdd,
                mission: mission.description
            }
        });
        
    } catch (error) {
        console.error('Error completing mission:', error);
        res.status(500).json({ error: error.message });
    }
};

// ============ HELPER FUNCTIONS ============

/**
 * Cộng điểm cho user
 */
async function addPoints(userId, amount, type, description) {
    // Update user points
    const userDoc = await db.collection(COLLECTIONS.USERS).doc(userId).get();
    const currentPoints = userDoc.data().points || 0;
    
    await db.collection(COLLECTIONS.USERS).doc(userId).update({
        points: currentPoints + amount
    });
    
    // Lưu lịch sử
    await db.collection(COLLECTIONS.POINTS_HISTORY).add({
        user_id: userId,
        amount: amount,
        type: 'earn',
        source: type,
        description: description,
        timestamp: new Date()
    });
}

/**
 * Lấy thời gian action cuối cùng
 */
async function getLastAction(userId, actionType) {
    const cacheKey = `last_${actionType}_${userId}`;
    
    // Trong production, dùng Redis
    // Ở đây dùng Firestore
    const doc = await db.collection('action_cache').doc(cacheKey).get();
    
    if (doc.exists) {
        return doc.data().timestamp;
    }
    
    return null;
}

/**
 * Set thời gian action cuối
 */
async function setLastAction(userId, actionType, timestamp) {
    const cacheKey = `last_${actionType}_${userId}`;
    
    await db.collection('action_cache').doc(cacheKey).set({
        user_id: userId,
        action_type: actionType,
        timestamp: timestamp
    });
}

/**
 * Đếm số lần action trong ngày
 */
async function getTodayCount(userId, actionType) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const snapshot = await db.collection(COLLECTIONS.POINTS_HISTORY)
        .where('user_id', '==', userId)
        .where('source', '==', actionType)
        .where('timestamp', '>=', today)
        .get();
    
    return snapshot.size;
}

/**
 * Kiểm tra nhiệm vụ đã hoàn thành chưa
 */
async function hasMissionCompleted(userId, missionId) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const snapshot = await db.collection(COLLECTIONS.POINTS_HISTORY)
        .where('user_id', '==', userId)
        .where('source', '==', 'daily_mission')
        .where('description', '==', missionId)
        .where('timestamp', '>=', today)
        .get();
    
    return !snapshot.empty;
}

/**
 * Đánh dấu nhiệm vụ hoàn thành
 */
async function markMissionCompleted(userId, missionId) {
    // Đã lưu trong addPoints
}
