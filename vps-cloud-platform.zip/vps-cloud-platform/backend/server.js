/**
 * VPS CLOUD VIETNAM - BACKEND SERVER
 * Node.js + Express + Firebase + GitHub Actions Integration
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// Serve static files (Frontend)
app.use(express.static('../frontend'));

// Load YAML configuration
const yamlLoader = require('./config/yaml-loader');
const config = yamlLoader.loadConfig();

// Initialize Firebase
require('./config/firebase');

// Routes
const authRoutes = require('./routes/auth');
const vpsRoutes = require('./routes/vps');
const pointsRoutes = require('./routes/points');

app.use('/api/auth', authRoutes);
app.use('/api/vps', vpsRoutes);
app.use('/api/points', pointsRoutes);

// Config endpoint
app.get('/api/config', (req, res) => {
    res.json(config);
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        system: config.system
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        timestamp: new Date().toISOString()
    });
});

// 404 handler
app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        res.status(404).json({ error: 'API endpoint not found' });
    } else {
        res.status(404).sendFile('index.html', { root: '../frontend' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log('╔═══════════════════════════════════════════════════════════════════╗');
    console.log('║         VPS CLOUD VIETNAM - BACKEND SERVER                        ║');
    console.log('╠═══════════════════════════════════════════════════════════════════╣');
    console.log(`║  🚀  Server running on port ${PORT}                                 ║`);
    console.log(`║  🌐  URL: http://localhost:${PORT}                                  ║`);
    console.log(`║  ⚙️   Environment: ${process.env.NODE_ENV || 'development'}         ║`);
    console.log(`║  📝  System: ${config.system.name} v${config.system.version}       ║`);
    console.log('╚═══════════════════════════════════════════════════════════════════╝');
});

module.exports = app;
